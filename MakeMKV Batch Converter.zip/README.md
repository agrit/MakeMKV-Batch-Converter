MakeMKV-Batch-Converter
=======================

Step 1. Zip the File and Open

Step 2. Install and Run

Step 3. Choose Folders or ISOs

Step 4. Choose Output Folder

Step 5. Click Start

Step 6. Have a Cold Drink and Watch Your DVD's Batch Convert:)
